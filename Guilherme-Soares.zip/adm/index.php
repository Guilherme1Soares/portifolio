<?php

$url = $_SERVER['REQUEST_URI'];

header('location: '.$url.'login');