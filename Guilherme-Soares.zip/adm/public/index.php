<?php 

echo 'Error 404';