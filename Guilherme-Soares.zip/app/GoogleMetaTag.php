<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GoogleMetaTag extends Model
{
    //
}
