<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Acompanhe extends Model
{
    //
}
